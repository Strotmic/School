#! /usr/bin/env sh

alembic upgrade head

exec "$@"

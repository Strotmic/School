namespace Howest.models;

public class Detect2
{
    public string id { get; set; }
    public string droneid { get; set; }
    public string target { get; set; }
    public string accuracy { get; set; }
    public string latitude { get; set; }
    public string longitude { get; set; }
    public string detectedObject { get; set; }
    public string isVerwerkt { get; set; }
    public string timestamp { get; set; }

}
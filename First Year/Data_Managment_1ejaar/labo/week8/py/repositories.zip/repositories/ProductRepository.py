from models.Product import Product
from repositories.Database import Database
from typing import List

class ProductRepository:

    @staticmethod
    def read_products_from_category(categorynumber: int) -> List[Product]:
        list_products = []

        if isinstance(categorynumber, int):
            sql = "SELECT ProductNumber, ProductName, PricePerUnit, CategoryNumber FROM tblproducts WHERE CategoryNumber=%s"
            sqlparams = [categorynumber]
            rows = Database.get_rows(sql, sqlparams)

            if rows is not None:
            
                for row in rows:
                    number = int(row["ProductNumber"])
                    name = row["ProductName"]
                    price = float(row["PricePerUnit"])
                    catnr = int(row["CategoryNumber"])
                    p = Product(number, name, catnr, price)
                    if p.isValid:
                        list_products.append(p)

        else:
            raise ValueError("Invalid categorynumber")
        
        return list_products
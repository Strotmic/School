from models.Category import Category
from repositories.Database import Database
from typing import List

class CategoryRepository:
    
    @staticmethod
    def read_all() -> List[Category]:
        list_categories = []
        rows = Database.get_rows("SELECT * FROM tblcategories")

        if rows is not None:
            for row in rows:
                number = int(row["CategoryNumber"])
                name = row["CategoryName"]
                description = row["Description"]
                c = Category(number, name, description)
                list_categories.append(c)

        return list_categories
    
    @staticmethod
    def create(cat: Category):
        if cat is not None and cat.isValid:
            sql = "INSERT INTO tblcategories(CategoryName, Description) VALUES (%s, %s)"
            params = [cat.categoryname, cat.description]
            catnr = Database.execute_sql(sql, params)
            if catnr is not None:
                cat.categorynumber = catnr
                return cat
            else:
                return None

        else:
            raise ValueError("Invalid Category")
    
    @staticmethod
    def update(cat: Category):
        if cat is not None and cat.isValid:
            sql = 'UPDATE tblcategories SET categoryname=%s, description=%s WHERE categorynumber=%s'
            params = [cat.categoryname, cat.description, cat.categorynumber]
            return Database.execute_sql(sql, params)
        
        else:
            raise ValueError("Invalid Category")
        
    @staticmethod
    def delete(catnr):
        if catnr is not None:
            sql = 'DELETE FROM tblcategories WHERE CategoryNumber = %s'
            params = [catnr]
            return Database.execute_sql(sql, params)
        
        else:
            raise ValueError("Invalid category number")

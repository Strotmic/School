from typing import Dict

class Category:

    def __init__(self, par_categorynumber: int, par_categoryname: str, par_description:str) -> None:
        self.__valueErrors = {}  #first
        self.categorynumber = par_categorynumber
        self.categoryname = par_categoryname
        self.description = par_description

    # ********** property valueErrors - (enkel getter) ***********
    @property
    def valueErrors(self) -> Dict[str,ValueError]:
        """ The valueErrors property. """
        return self.__valueErrors

    # ********** property isValid - (enkel getter) ***********
    @property
    def isValid(self) -> bool:
        """ The isValid property. """
        return len(self.__valueErrors) == 0
    
    
    # ********** property categorynumber - (setter/getter) ***********
    @property
    def categorynumber(self) -> int:
        """ The categorynumber property. """
        return self.__categorynumber
    
    @categorynumber.setter
    def categorynumber(self, value: int) -> None:
        if isinstance(value,int):
            self.__categorynumber = value
        else:
            self.__valueErrors['categorynumber'] = ValueError("No valid categorynumber")
            #raise ValueError("No valid categorynumber!")
    
    # ********** property categoryname - (setter/getter) ***********
    @property
    def categoryname(self) -> str:
        """ The categoryname property. """
        return self.__categoryname
    
    @categoryname.setter
    def categoryname(self, value: str) -> None:
        if isinstance(value,str) and value != "":
            self.__categoryname = value
        else:
            self.__valueErrors['categoryname'] = ValueError("No valid categoryname!")
            #raise ValueError("No valid categoryname!")
    
    # ********** property description - (setter/getter) ***********
    @property
    def description(self) -> str:
        """ The description property. """
        return self.__description
    
    @description.setter
    def description(self, value: str) -> None:
        if not isinstance(value,str) :
            self.__valueErrors['description'] = ValueError("No valid description")
        elif len(value) > 50 :
            self.__valueErrors['description length'] = ValueError("Max length of 50 characters.")
        else:
            self.__description = value            

    def __str__(self) -> str:
        return f"\n{self.categorynumber}\t\t{self.categoryname} \t\t{self.description}  "
    
    def __repr__(self) -> str:
        return f"{self.categoryname}"
from repositories.Database import Database
from models.Category import Category
from typing import Dict

class Product:
    
    def __init__(self, par_productnumber: int, par_productname: str,  par_categorynumber: int, par_priceperunit: float) -> None:
        self.__valueErrors = {}
        self.productnumber = par_productnumber
        self.productname = par_productname
        self.categorynumber = par_categorynumber
        self.priceperunit = par_priceperunit

    # ********** property valueErrors - (enkel getter) ***********
    @property
    def valueErrors(self) -> Dict[str,ValueError]:
        """ The valueErrors property. """
        return self.__valueErrors

    # ********** property isValid - (enkel getter) ***********
    @property
    def isValid(self) -> bool:
        """ The isValid property. """
        return len(self.__valueErrors) == 0

    # ********** property productnumber - (setter/getter) ***********
    @property
    def productnumber(self) -> int:
        """ The productnumber property. """
        return self.__productnumber
    
    @productnumber.setter
    def productnumber(self, value: int) -> None:
        if isinstance(value, int) and value > 0:
            self.__productnumber = value
        else:
            self.__valueErrors["productnumber"] = ValueError("Invalid productnumber")

    # ********** property productname - (setter/getter) ***********
    @property
    def productname(self) -> str:
        """ The productname property. """
        return self.__productname
    
    @productname.setter
    def productname(self, value: str) -> None:
        if isinstance(value, str) and value != "":
            self.__productname = value
        else:
            self.__valueErrors["productname"] = ValueError("Invalid productname")
    
    # ********** property categorynumber - (setter/getter) ***********
    @property
    def categorynumber(self) -> int:
        """ The categorynumber property. """
        return self.__categorynumber
    
    @categorynumber.setter
    def categorynumber(self, value: int) -> None:
        if isinstance(value, int) and value > 0:
            self.__categorynumber = value
        else:
            self.__valueErrors["categorynumber"] = ValueError("Invalid categorynumber")
    
    # ********** property priceperunit - (setter/getter) ***********
    @property
    def priceperunit(self) -> float:
        """ The priceperunit property. """
        return self.__priceperunit
    
    @priceperunit.setter
    def priceperunit(self, value: float) -> None:
        if isinstance(value, float) and value >= 0:
            self.__priceperunit = value   
        else:
            self.__valueErrors["priceperunit"] = ValueError("Invalid priceperunit")

    def __str__(self) -> str:
        return f"{self.productname}, price: {self.priceperunit}  "

    def __repr__(self) -> str:
        return f"{self.productname}"
from repositories.CategoryRepository import CategoryRepository
from models.Category import Category
from tabulate import tabulate

class CategoryServices:

    @staticmethod
    def print_all_categories():
        table = []
        for cat in CategoryRepository.read_all():
            row = [cat.categorynumber, cat.categoryname, cat.description]
            table.append(row)
        print(tabulate(table, headers=["Nr", "Name", "Description"]))

    @staticmethod
    def add_category(categoryname: str, description: str) -> Category:
        cat = Category(categoryname, description)
        if cat.isValid:
            print("Categorie toegevoegd")
            return CategoryRepository.create(cat)
        
        else:
            print("ADD mislukt")

    @staticmethod
    def update_category(categoryname: str, description: str, categorynumber: int) -> Category:
        cat = Category(categorynumber, categoryname, description)
        if cat.isValid:
            print("Categorie geüpdate")
            return CategoryRepository.update(cat)
        
        else:
            print("UPDATE mislukt")

    @staticmethod
    def delete_category(categorynumber: int) -> None:
        if categorynumber is not None:
            print("category gedeleted")
            return CategoryRepository.delete(categorynumber)
        
        else:
            print("DELETE mislukt")
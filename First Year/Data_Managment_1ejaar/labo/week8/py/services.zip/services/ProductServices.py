from repositories.ProductRepository import ProductRepository
from models.Product import Product
from tabulate import tabulate

class ProductServices:

    @staticmethod
    def print_products_from_category(categorynumber: int):
        list_products = ProductRepository.read_products_from_category(categorynumber)
        print(list_products)
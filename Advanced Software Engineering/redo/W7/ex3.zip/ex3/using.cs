global using System.ComponentModel.DataAnnotations;
global using redo.w7.ex3.models;
global using redo.w7.ex3.repos;
global using redo.w7.ex3.services;
global using redo.w7.ex3.data;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.DependencyInjection;

global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Threading.Tasks;
global using System.Diagnostics;
global using System.IO;
global using System.Net;
global using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
